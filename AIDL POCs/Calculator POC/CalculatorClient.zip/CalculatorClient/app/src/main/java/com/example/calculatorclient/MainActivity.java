package com.example.calculatorclient;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import com.example.calculatorserver.IMyAidlInterface;
import androidx.fragment.app.FragmentActivity;

/*
 * Main Activity class that loads {@link MainFragment}.
 */
public class MainActivity extends AppCompatActivity {

    IMyAidlInterface iMyAidlService;
    private static final String TAG ="MainActivity";
    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            iMyAidlService = IMyAidlInterface.Stub.asInterface(iBinder);
            Log.d(TAG, "Remote config Service Connected!!");
            System.out.println("Connected");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.example.calculatorserver",
                "com.example.calculatorserver.CalculatorService"));
        System.out.println("Intent "+ intent);
        intent.setPackage("com.example.calculatorserver");
        System.out.println("Intent "+ intent);
        bindService(intent, mConnection, BIND_AUTO_CREATE);
        System.out.println("Checking...");

        EditText t1 = findViewById(R.id.editTextText);
        EditText t2 = findViewById(R.id.editTextText2);
        Button b1 = findViewById(R.id.button2);
        Button b2 = findViewById(R.id.button3);
        Button b3 = findViewById(R.id.button4);
        Button b4 = findViewById(R.id.button5);
        TextView t3 = findViewById(R.id.textView2);


        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String input1 = t1.getText().toString().trim();
                String input2 = t2.getText().toString().trim();

                if (input1.isEmpty() || input2.isEmpty()) {
                    t3.setText("Please enter both numbers");
                    return;
                }
                int sum = 0;
                try {
                    int v1 = Integer.parseInt(input1);
                    int v2 = Integer.parseInt(input2);
                    sum = iMyAidlService.getSum(v1,v2);
                    t3.setText(v1 + " + " + v2 + " = " + sum);
                } catch (RemoteException e) {
                    throw new RuntimeException(e);
                }

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input1 = t1.getText().toString().trim();
                String input2 = t2.getText().toString().trim();

                if (input1.isEmpty() || input2.isEmpty()) {
                    t3.setText("Please enter both numbers");
                    return;
                }
                int diff = 0;
                try {
                    int v1 = Integer.parseInt(input1);
                    int v2 = Integer.parseInt(input2);
                    diff = iMyAidlService.getDiff(v1,v2);
                    t3.setText(v1 + " - " + v2 + " = " + diff);
                } catch (RemoteException e) {
                    throw new RuntimeException(e);
                }

            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input1 = t1.getText().toString().trim();
                String input2 = t2.getText().toString().trim();

                if (input1.isEmpty() || input2.isEmpty()) {
                    t3.setText("Please enter both numbers");
                    return;
                }
                int mul = 0;
                try {
                    int v1 = Integer.parseInt(input1);
                    int v2 = Integer.parseInt(input2);
                    mul = iMyAidlService.getMul(v1,v2);
                    t3.setText(v1 + " * " + v2 + " = " + mul);
                } catch (RemoteException e) {
                    throw new RuntimeException(e);
                }

            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input1 = t1.getText().toString().trim();
                String input2 = t2.getText().toString().trim();

                if (input1.isEmpty() || input2.isEmpty()) {
                    t3.setText("Please enter both numbers");
                    return;
                }
                double div = 0.0;
                try {
                    int v1 = Integer.parseInt(input1);
                    int v2 = Integer.parseInt(input2);
                    if(v2 != 0) {
                        div = iMyAidlService.getDiv(v1, v2);
                        t3.setText(v1 + " / " + v2 + " = " + div);
                    }
                    else{
                        t3.setText(v1 + " / " + v2 + " = Invaid Input can't divide by 0");
                    }

                } catch (RemoteException e) {
                    throw new RuntimeException(e);
                }

            }
        });
    }
}