package com.example.calculatorserver;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Random;

public class CalculatorService extends Service {

    private static final String TAG = "CalculatorService";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind: " + intent+" binder "+binder);
        return binder;
    }

    private final IMyAidlInterface.Stub binder = new IMyAidlInterface.Stub() {


        @Override
        public int getSum(int a, int b) throws RemoteException {
            return a + b;
        }

        @Override
        public int getDiff(int a, int b) throws RemoteException {
            return a - b;
        }

        @Override
        public int getMul(int a, int b) throws RemoteException {
            return a * b;
        }

        @Override
        public float getDiv(int a, int b) throws RemoteException {
            return (float) a /b;
        }
    };
}
