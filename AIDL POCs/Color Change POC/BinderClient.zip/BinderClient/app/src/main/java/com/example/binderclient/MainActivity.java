package com.example.binderclient;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.colorchangenew.IMyAidlInterface;

/*
 * Main Activity class that loads {@link MainFragment}.
 */
public class MainActivity extends AppCompatActivity {

    IMyAidlInterface iMyAidlService;
    private static final String TAG ="MainActivity";
    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            iMyAidlService = IMyAidlInterface.Stub.asInterface(iBinder);
            Log.d(TAG, "Remote config Service Connected!!");
            System.out.println("Connected");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.example.colorchangenew",
                "com.example.colorchangenew.AIDLColorService"));
        System.out.println("Intent "+ intent);
        intent.setPackage("com.example.colorchangeNew");
        System.out.println("Intent "+ intent);
        bindService(intent, mConnection, BIND_AUTO_CREATE);
        System.out.println("Checking...");

        //create an onClick
        Button b = findViewById(R.id.button2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int color = 0;
                System.out.println("color" + color);
                System.out.println("2nd here iMyAidlService "+iMyAidlService);
                try {
                    if (iMyAidlService != null) {
                        color = iMyAidlService.getColor();
                        view.setBackgroundColor(color);
                    } else {
                        Toast.makeText(MainActivity.this, "Service not connected yet", Toast.LENGTH_SHORT).show();
                    }

                } catch (RemoteException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Color " + color);
                view.setBackgroundColor(color);

            }
        });

    }
}