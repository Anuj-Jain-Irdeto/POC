package com.example.timezoneclient;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextClock;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import com.example.timezoneserver.IMyAidlInterface;

import java.util.TimeZone;

/*
 * Main Activity class that loads {@link MainFragment}.
 */
public class MainActivity extends AppCompatActivity {

    IMyAidlInterface iMyAidlService;

    private static final String TAG ="MainActivity";

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            iMyAidlService = IMyAidlInterface.Stub.asInterface(iBinder);
            Log.d(TAG, "Remote config Service Connected!!");
            System.out.println("Connected");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.example.timezoneserver",
                "com.example.timezoneserver.TimeZoneService"
        ));
        intent.setPackage("com.example.timezoneserver");
        bindService(intent, mConnection, BIND_AUTO_CREATE);
        Spinner spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.timezone_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        Button b = findViewById(R.id.button2);
        TextClock tc = findViewById(R.id.textClock);
        TextView tv = findViewById(R.id.textView);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String convTime = "";
                String currTime = tc.getText().toString();
                String sourceTimeZoneId = TimeZone.getDefault().getID();
                int selectedIndex = spinner.getSelectedItemPosition();
                String[] timeZoneIds = getResources().getStringArray(R.array.timezone_ids);
                String targetTimeZoneId = timeZoneIds[selectedIndex];
                try {
                    convTime = iMyAidlService.getTime(currTime, sourceTimeZoneId,targetTimeZoneId);
                } catch (RemoteException e) {
                    throw new RuntimeException(e);
                }
                tv.setText(convTime);
            }
        });
    }
}