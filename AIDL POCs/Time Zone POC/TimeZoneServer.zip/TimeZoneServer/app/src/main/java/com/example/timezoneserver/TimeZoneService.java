package com.example.timezoneserver;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.Nullable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class TimeZoneService extends Service {

    private static final String TAG = "TimeZoneService";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind: " + intent+" binder "+binder);
        return binder;
    }

    private final IMyAidlInterface.Stub binder = new IMyAidlInterface.Stub() {

        @Override
        public String getTime(String currTime, String sourceZone, String targetZone) throws RemoteException {
            currTime = currTime.replaceAll("\\s+", " ").trim();  // normalize spacing
            currTime = currTime.replace('\u202F', ' ');
            System.out.println("Source Zone: " + sourceZone);
            System.out.println("Target Zone: " + targetZone);
            SimpleDateFormat inputFormat = new SimpleDateFormat("hh:mm a");
            inputFormat.setTimeZone(TimeZone.getTimeZone(sourceZone));
            System.out.println(inputFormat);

            SimpleDateFormat outputFormat = new SimpleDateFormat("hh:mm a");
            outputFormat.setTimeZone(TimeZone.getTimeZone(targetZone));
            System.out.println(outputFormat);
            try {
                System.out.println("Curr" + currTime);
                Date date = inputFormat.parse(currTime);
                System.out.println("Data"+date);
                return outputFormat.format(date);
            } catch (ParseException e) {
                e.printStackTrace();
                return "Invalid time format";
            }
        }
    };
}
