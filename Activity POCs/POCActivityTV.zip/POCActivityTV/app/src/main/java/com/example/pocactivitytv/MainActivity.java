package com.example.pocactivitytv;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.FragmentActivity;

/*
 * Main Activity class that loads {@link MainFragment}.
 */
public class MainActivity extends FragmentActivity {

    Button btn;
    Button btn2;
    EditText txt1;
    EditText txt2;
    Button btn3;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.button2);
        btn2 = findViewById(R.id.button3);
        btn3 = findViewById(R.id.button4);
        txt1 = (EditText) findViewById(R.id.editTextText);
        txt2 = (EditText) findViewById(R.id.editTextText1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("POC for Activity TV");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("opening Gmail");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txt2.getText().toString().equals("Pass")){
                   System.out.println("hello " + txt1.getText().toString());
                }
                else{
                    System.out.println("Please Enter Correct Password");
                }
            }
        });

    }
}