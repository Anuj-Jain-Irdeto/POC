package com.example.broadcastreceiverpoc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.widget.TextView;
import android.widget.Toast;

public class BatteryBroadcastReceiver extends BroadcastReceiver {
    TextView tv;
    @Override
    public void onReceive(Context context, Intent intent) {
        int level = intent.getIntExtra("level", -1);
        int status = intent.getIntExtra("status", -1);
        String statusString = getBatteryStatus(status);
        int health = intent.getIntExtra("health", -1);
        String healthString = getBatteryHealth(health);
        int plugged = intent.getIntExtra("plugged", -1);
        String pluggedString = getBatteryPlugged(plugged);
        String message = "Battery Level: " + level + "%\n"
                + "Battery Status: " + statusString + "\n"
                + "Battery Health: " + healthString + "\n"
                + "Charger Connection: " + pluggedString;
        System.out.println("Message: " + message);
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();


    }
    private String getBatteryStatus(int status){
        switch(status){
            case BatteryManager.BATTERY_STATUS_CHARGING:
                return "Charging";
            case BatteryManager.BATTERY_STATUS_DISCHARGING:
                return "Discharging";
            case BatteryManager.BATTERY_STATUS_FULL:
                return "Full";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                return "Not Charging";
            default:
                return "Unknown";
        }
    }
    private String getBatteryHealth(int health){
        switch(health){
            case BatteryManager.BATTERY_HEALTH_COLD:
                return "Cold";
            case BatteryManager.BATTERY_HEALTH_DEAD:
                return "Dead";
            case BatteryManager.BATTERY_HEALTH_GOOD:
                return "Good";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                return "Over Voltage";
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                return "Unspecified Failure";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                return "OverHeat";
            default:
                return "Unknown";
        }
    }
    private String getBatteryPlugged(int plugged){
        switch(plugged){
            case BatteryManager.BATTERY_PLUGGED_AC:
                return "AC Charging";
            case BatteryManager.BATTERY_PLUGGED_WIRELESS:
                return "Wireless Charging";
            case BatteryManager.BATTERY_PLUGGED_DOCK:
                return "Dock Charging";
            case BatteryManager.BATTERY_PLUGGED_USB:
                return "USB Charging";
            default:
                return "None";
        }
    }
}
