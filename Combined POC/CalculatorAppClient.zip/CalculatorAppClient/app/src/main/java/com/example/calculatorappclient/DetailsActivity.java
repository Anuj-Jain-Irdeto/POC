package com.example.calculatorappclient;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.calculator.ICalculatorService;

import java.util.ArrayList;
import java.util.List;

public class DetailsActivity extends AppCompatActivity {

    EditText et1, et2;
    Button b1, b2, b3, b4, b5, b6;
    TextView tv;
    ICalculatorService iCalculatorService;

    private static final String TAG = "DetailsActivity";
    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            iCalculatorService = ICalculatorService.Stub.asInterface(iBinder);
            Log.d(TAG, "Service connected");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            iCalculatorService = null;
            Log.d(TAG, "Service disconnected");
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        // Bind to remote service
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.example.calculatorappserver",
                "com.example.calculatorappserver.CalculatorService"
        ));
        intent.setPackage("com.example.calculatorappserver");
        bindService(intent, mConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unbindService(mConnection);
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        et1 = findViewById(R.id.editTextText);
        et2 = findViewById(R.id.editTextText2);
        b1 = findViewById(R.id.button3); // Add
        b2 = findViewById(R.id.button4); // Subtract
        b3 = findViewById(R.id.button5); // Multiply
        b4 = findViewById(R.id.button6); // Divide
        b5 = findViewById(R.id.button7); // History
        b6 = findViewById(R.id.button8); // Go back
        tv = findViewById(R.id.textView);

        b6.setOnClickListener(v -> {
            startActivity(new Intent(DetailsActivity.this, MainActivity.class));
        });

        b1.setOnClickListener(v -> performOperation("+"));
        b2.setOnClickListener(v -> performOperation("-"));
        b3.setOnClickListener(v -> performOperation("*"));
        b4.setOnClickListener(v -> performOperation("/"));
        b5.setOnClickListener(v -> showHistoryDialog());
    }

    @SuppressLint("MissingInflatedId")
    private void showHistoryDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.activity_history, null);
        LinearLayout container = dialogView.findViewById(R.id.dialog_history_container);

        try {
            List<String> history = iCalculatorService.getHistory();
            Log.d("HistoryActivity", "History: " + history);

            if (history.isEmpty()) {
                TextView emptyView = new TextView(this);
                emptyView.setText("No history available.");
                emptyView.setTextSize(16);
                emptyView.setPadding(20, 30, 20, 30);
                container.addView(emptyView);
            } else {
                for (int i = 0; i < history.size(); i++) {
                    String hist = history.get(i);
                    TextView tv = new TextView(this);
                    tv.setText(hist);
                    tv.setTextSize(16);
                    tv.setFocusable(false);
                    tv.setFocusableInTouchMode(false);
                    tv.setPadding(20, 20, 20, 20);
                    tv.setTextColor(getResources().getColor(android.R.color.black));
                    int bgColor = (i % 2 == 0)
                            ? getResources().getColor(R.color.stripe_dark)
                            : getResources().getColor(R.color.stripe_light);

                    tv.setBackgroundColor(bgColor);
                    container.addView(tv);
                }
            }
        } catch (RemoteException e) {
            Log.e("HistoryActivity", "Failed to get history", e);
            TextView errorView = new TextView(this);
            errorView.setText("Error retrieving history.");
            errorView.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            container.addView(errorView);
        }

        new AlertDialog.Builder(this)
                .setTitle("Calculation History")
                .setView(dialogView)
                .setPositiveButton("X", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void showTimeOverDialog(){
        runOnUiThread(() ->{
            new AlertDialog.Builder(DetailsActivity.this)
            .setTitle("Time Limit Reached")
            .setMessage("You have reached the allowed usage time.")
            .setCancelable(false)
            .setPositiveButton("OK", (dialog, which) ->{
                Intent intent = new Intent(DetailsActivity.this, MainActivity.class);
                startActivity(intent);
            }).show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (getIntent().getBooleanExtra("SHOW_DIALOG", false)) {
            showTimeOverDialog();
            getIntent().removeExtra("SHOW_DIALOG");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    private void performOperation(String operator) {
        String inp1 = et1.getText().toString().trim();
        String inp2 = et2.getText().toString().trim();

        if (inp1.isEmpty() || inp2.isEmpty()) {
            tv.setText("Please enter both numbers.");
            return;
        }

        if (iCalculatorService == null) {
            tv.setText("Service not connected. Try again shortly.");
            return;
        }

        try {
            double v1 = Double.parseDouble(inp1);
            double v2 = Double.parseDouble(inp2);

            if (operator.equals("/") && v2 == 0) {
                tv.setText("Cannot divide by zero.");
                return;
            }

            double result = iCalculatorService.performOperation(v1, v2, operator);
            String symbol = operator.equals("*") ? "×" : operator.equals("/") ? "÷" : operator;
            tv.setText(v1 + " " + symbol + " " + v2 + " = " + result);
        } catch (NumberFormatException e) {
            tv.setText("Invalid number format.");
        } catch (RemoteException e) {
            tv.setText("Remote error: " + e.getMessage());
            Log.e(TAG, "RemoteException", e);
        }

    }
}
