package com.example.calculatorappclient;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EmpActivity extends AppCompatActivity {

    Button btn, load, fetch;
    EditText name, email;
    RadioGroup selectedEmp,selectedMode;
    SQLiteDatabase sqLiteDatabase;
    TableLayout table;

    @SuppressLint("MissingInflatedId")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp);
        btn = findViewById(R.id.close);
        btn.setOnClickListener(v -> {
            Intent intent = new Intent(EmpActivity.this, MainActivity.class);
            startActivity(intent);
        });
        load = findViewById(R.id.btnInsert);
        fetch = findViewById(R.id.btnFetch);
        name = findViewById(R.id.etName);
        email = findViewById(R.id.etEmail);
        selectedEmp = findViewById(R.id.rgEmployment);
        selectedMode = findViewById(R.id.rgWorkMode);
        table = findViewById(R.id.tableLayout);
        load.setOnClickListener(v -> {
            System.out.println("Inserting...");
            int selectedEmpType = selectedEmp.getCheckedRadioButtonId();
            RadioButton emp = findViewById(selectedEmpType);
            int selectedWorkMode = selectedMode.getCheckedRadioButtonId();
            RadioButton mode = findViewById(selectedWorkMode);
            String sql = "INSERT INTO EMPTABLE (NAME, EMAIL, EMPLOYMENT_TYPE, WORK_MODE) VALUES (?, ?, ?, ?)";
            sqLiteDatabase.execSQL(sql, new Object[]{
                    name.getText(),
                    email.getText(),
                    emp.getText(),
                    mode.getText()
            });
            Toast.makeText(this, "Inserted data Successfully", Toast.LENGTH_SHORT).show();
            System.out.println("Data Loaded");
        });
        fetch.setOnClickListener(v ->{
            System.out.println("Fetching...");
            table.removeAllViews();
            TableRow header = new TableRow(this);
            String[] headerTitles = {"Name", "Email", "Employment Type", "Work Mode"};
            for (String title: headerTitles){
                TextView tv = new TextView(this);
                tv.setText(title);
                tv.setPadding(16,16,16,16);
                tv.setTypeface(null, Typeface.BOLD);
                header.addView(tv);
            }
            table.addView(header);
            Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM EMPTABLE", null);
            if(cursor!=null && cursor.moveToFirst()){
                int nameIndex = cursor.getColumnIndexOrThrow("NAME");
                int emailIndex = cursor.getColumnIndexOrThrow("EMAIL");
                int empIndex = cursor.getColumnIndexOrThrow("EMPLOYMENT_TYPE");
                int modeIndex = cursor.getColumnIndexOrThrow("WORK_MODE");
                do{
                    String nameStr = cursor.getString(nameIndex);
                    String emailStr = cursor.getString(emailIndex);
                    String empStr = cursor.getString(empIndex);
                    String modeStr = cursor.getString(modeIndex);
                    TableRow row = new TableRow(this);
                    String[] values = {nameStr, emailStr, empStr, modeStr};
                    for (String value: values){
                        TextView tv = new TextView(this);
                        tv.setText(value);
                        tv.setPadding(16,16,16,16);
                        row.addView(tv);
                    }
                    table.addView(row);
                } while (cursor.moveToNext());
                cursor.close();
                System.out.println("Data Fetched" + table.getChildCount() + "rows");
            } else{
                TextView empty = new TextView(this);
                empty.setText("No records found.");
                empty.setPadding(16,16,16,16);
                table.addView(empty);
            }
        });
        System.out.println("Create DB");
        sqLiteDatabase = openOrCreateDatabase("MyDB", MODE_PRIVATE, null);
        System.out.println("Create Table");
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS EMPTABLE(NAME TEXT, EMAIL TEXT, EMPLOYMENT_TYPE TEXT, WORK_MODE TEXT)");
    }
}
