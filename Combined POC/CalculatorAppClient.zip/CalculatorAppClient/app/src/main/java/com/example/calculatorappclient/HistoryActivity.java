package com.example.calculatorappclient;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.calculator.ICalculatorService;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    ICalculatorService iCalculatorService;
    List<String> history = new ArrayList<>();
    private static final String TAG = "HistoryActivity";

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            iCalculatorService = ICalculatorService.Stub.asInterface(iBinder);
            Log.d(TAG, "Service connected");
            System.out.println("hi");
            try {
                history = iCalculatorService.getHistory();
                Log.d(TAG, "History: " + history);
                System.out.println(history);
                for (String hist : history) {
                    TextView tv = new TextView(HistoryActivity.this);
                    tv.setText(hist);
                }
            } catch (RemoteException e) {
                Log.e(TAG, "Failed to get history", e);
            }
        }


        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            iCalculatorService = null;
            Log.d(TAG, "Service disconnected");
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        // Bind to remote service
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.example.calculatorappserver",
                "com.example.calculatorappserver.CalculatorService"
        ));
        intent.setPackage("com.example.calculatorappserver");
        bindService(intent, mConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unbindService(mConnection);
    }
    Button b1;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        System.out.println("HI Going Inside");
        try {
            history = iCalculatorService.getHistory();
            System.out.println("History"+ history);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
        for(String hist: history){
            TextView tv = new TextView(this);
            tv.setText(hist);
        }
    }
}
