package com.example.calculatorappclient;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class TimeBroadcastreceiver extends BroadcastReceiver {
    private static final String TAG = "TimeBroadcastReceiver";
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, "Broadcast received: " + action);
        if ("com.example.calculator.ONE_MINUTE_EXCEEDED".equals(action)){
            Toast.makeText(context, "One minute over!", Toast.LENGTH_SHORT).show();
        }
        else if ("com.example.calculator.TIME_OVER".equals(action)){
            Intent dialogIntent = new Intent(context, DetailsActivity.class);
            dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            dialogIntent.putExtra("SHOW_DIALOG", true);
            context.startActivity(dialogIntent);
        }
    }
}
