package com.example.calculatorappserver;

import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.calculator.ICalculatorService;

import java.util.ArrayList;
import java.util.List;

public class CalculatorService extends Service{
    private boolean isTracking = false;
    private boolean oneMinuteBroadcastSent = false;

    private long startTime = 0L;
    private final List<String> history = new ArrayList<>();
    SQLiteDatabase sqLiteDatabase;
    private String TAG = "CalculatorService";

    private final ICalculatorService.Stub binder = new ICalculatorService.Stub() {
        @Override
        public double performOperation(double num1, double num2, String operator) throws RemoteException {
            double result = 0;
            switch (operator) {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "/":
                    result = num1 / num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
            }
            String sql = "INSERT INTO OPERATION (NUM1, NUM2, OPERATOR, RESULT) VALUES (?,?,?,?)";
            sqLiteDatabase.execSQL(sql, new Object[]{
                    num1,
                    num2,
                    operator,
                    result
            });
            return result;
        }

        @Override
        public List<String> getHistory() {
            List<String> history = new ArrayList<>();
            Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM OPERATION", null);
            if (cursor != null & cursor.moveToFirst()){
                int num1Index = cursor.getColumnIndexOrThrow("NUM1");
                int num2Index = cursor.getColumnIndexOrThrow("NUM2");
                int operatorIndex = cursor.getColumnIndexOrThrow("OPERATOR");
                int resultIndex = cursor.getColumnIndexOrThrow("RESULT");
                do{
                    double num1 = cursor.getDouble(num1Index);
                    double num2 = cursor.getDouble(num2Index);
                    String operator = cursor.getString(operatorIndex);
                    double result = cursor.getDouble(resultIndex);
                    String symbol = operator.equals("*") ? "×" : operator.equals("/") ? "÷" : operator;
                    String entry = num1 + " " + symbol + " " + num2 + " = " + result;
                    history.add(entry);
                }while (cursor.moveToNext());
                cursor.close();
            }
            else {
                String empty = "No Record";
                history.add(empty);
            }
            return history;
        }

        @Override
        public void clearHistory() throws RemoteException {
            history.clear();
        }

        @Override
        public long getUsageTime() throws RemoteException {
            if (!isTracking) return 0;
            return System.currentTimeMillis() - startTime;
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        sqLiteDatabase = openOrCreateDatabase("MyDB", MODE_PRIVATE, null);

        Log.d(TAG, "Creating OPERATION if not exists...");
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS OPERATION(NUM1 DOUBLE, NUM2 DOUBLE, OPERATOR TEXT, RESULT DOUBLE)");
        Log.d(TAG, "Database initialized.");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        startTracking();
        return binder;
    }
    private void startTracking(){
        if (!isTracking){
            startTime =  System.currentTimeMillis();
            System.out.println("Tracking started");
            isTracking = true;
            System.out.println("Tracking" + isTracking);
            new Thread(() ->{
                System.out.println("created thread");
                try{
                    while(isTracking){
                        long usage = System.currentTimeMillis() - startTime;
                        System.out.println("Usage: "+ usage);
                        if (usage > 2 * 60 * 1000){
                            Intent intent = new Intent("com.example.calculator.TIME_OVER");
                            intent.setPackage("com.example.calculatorappclient");
                            System.out.println("TIME OVER");
                            sendBroadcast(intent);
                            isTracking = false;
                        }
                        else if (usage >= 1 * 60 * 1000 && !oneMinuteBroadcastSent){
                            Intent intent = new Intent("com.example.calculator.ONE_MINUTE_EXCEEDED");
                            intent.setPackage("com.example.calculatorappclient");
                            System.out.println("ONE MINUTE OVER");
                            sendBroadcast(intent);
                            oneMinuteBroadcastSent = true;
                        }
                        Thread.sleep(5*1000);
                    }
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }).start();
        }
    }
    public boolean onUnbind(Intent intent) {
        isTracking = false;
        return super.onUnbind(intent);
    }
}
