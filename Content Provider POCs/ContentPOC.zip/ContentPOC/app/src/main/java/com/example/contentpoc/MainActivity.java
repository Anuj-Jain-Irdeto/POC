package com.example.contentpoc;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

/*
 * Main Activity class that loads {@link MainFragment}.
 */
public class MainActivity extends Activity {

    TextView name, data;
    Button loadbtn, fetchBtn;
    SQLiteDatabase sqLiteDatabase;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.editTextText);
        data = findViewById(R.id.textView2);
        loadbtn = findViewById(R.id.button3);
        fetchBtn = findViewById(R.id.button2);
        loadbtn.setOnClickListener(View ->{
            System.out.println("INSERTING");
            sqLiteDatabase.execSQL("INSERT INTO MYTABLE(NAME) VALUES('" + name.getText() + "');");
        });
        fetchBtn.setOnClickListener(View ->{
            System.out.println("FETCHING");
            Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM MYTABLE", null);
            cursor.moveToFirst();
            System.out.println("Data Fetched " + cursor.getCount());
            if (null != cursor && cursor.moveToFirst()){
                do{
                    String name = cursor.getString(0);
                    System.out.println("Data Fetched Value " + name);
                    data.setText(name);
                } while (cursor.moveToNext());
            }
        });
        System.out.println("Create DB");
        sqLiteDatabase = openOrCreateDatabase("MyDB", MODE_PRIVATE, null);
        System.out.println("Create Table");
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS MYTABLE(NAME TEXT)");
    }
}