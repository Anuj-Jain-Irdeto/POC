package com.example.contentprovider;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

/*
 * Main Activity class that loads {@link MainFragment}.
 */
public class MainActivity extends Activity {

    Button load, fetch;
    EditText name, email;
    RadioGroup subscriptionSelected, statusSelected;
    SQLiteDatabase sqLiteDatabase;
    TableLayout table;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        load = findViewById(R.id.btnInsert);
        fetch = findViewById(R.id.btnFetch);
        name = findViewById(R.id.etName);
        email = findViewById(R.id.etEmail);
        subscriptionSelected = findViewById(R.id.rgSubscription);
        statusSelected = findViewById(R.id.rgStatus);
        table = findViewById(R.id.tableLayout);
        load.setOnClickListener(View ->{
            System.out.println("Inserting...");
            int selectedId = subscriptionSelected.getCheckedRadioButtonId();
            RadioButton subscription = findViewById(selectedId);
            int selectedRadio =  statusSelected.getCheckedRadioButtonId();
            RadioButton status = findViewById(selectedRadio);
            String sql = "INSERT INTO CUSTTABLE (NAME, EMAIL, SUBSCRIPTION_TYPE, STATUS) VALUES (?, ?, ?, ?)";
            sqLiteDatabase.execSQL(sql, new Object[]{
                    name.getText(),
                    email.getText(),
                    subscription.getText(),
                    status.getText()
            });
            Toast.makeText(this, "Inserted Data Successfully", Toast.LENGTH_SHORT).show();
            System.out.println("Data Loaded");
        });
        fetch.setOnClickListener(View -> {
            System.out.println("Fetching...");
            table.removeAllViews();
            TableRow header = new TableRow(this);
            String[] headerTitles = {"Name", "Email", "Subscription", "Status"};
            for (String title : headerTitles) {
                TextView tv = new TextView(this);
                tv.setText(title);
                tv.setPadding(16, 16, 16, 16);
                tv.setTypeface(null, Typeface.BOLD);
                header.addView(tv);
            }
            table.addView(header);
            Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM CUSTTABLE", null);

            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndexOrThrow("NAME");
                int emailIndex = cursor.getColumnIndexOrThrow("EMAIL");
                int subIndex = cursor.getColumnIndexOrThrow("SUBSCRIPTION_TYPE");
                int statusIndex = cursor.getColumnIndexOrThrow("STATUS");
                do {
                    String nameStr = cursor.getString(nameIndex);
                    String emailStr = cursor.getString(emailIndex);
                    String subStr = cursor.getString(subIndex);
                    String statusStr = cursor.getString(statusIndex);
                    TableRow row = new TableRow(this);
                    String[] values = {nameStr, emailStr, subStr, statusStr};
                    for (String value : values) {
                        TextView tv = new TextView(this);
                        tv.setText(value);
                        tv.setPadding(16, 16, 16, 16);
                        row.addView(tv);
                    }
                    table.addView(row);
                } while (cursor.moveToNext());
                cursor.close();
                System.out.println("Data Fetched " + table.getChildCount() + " rows");
            } else {
                TextView empty = new TextView(this);
                empty.setText("No records found.");
                empty.setPadding(16, 16, 16, 16);
                table.addView(empty);
            }
        });

        System.out.println("Create DB");
        sqLiteDatabase = openOrCreateDatabase("MyDB", MODE_PRIVATE, null);
        System.out.println("Create Table");
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS CUSTTABLE(NAME TEXT, EMAIL TEXT, SUBSCRIPTION_TYPE TEXT, STATUS TEXT)");
    }
}